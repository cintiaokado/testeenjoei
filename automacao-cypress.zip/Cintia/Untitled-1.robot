*** Settings ***
Library    AppiumLibrary

*** Variables ***
${EMAIL}     accessibility_id=email_input
${SENHA}     accessibility_id=password_input
${ENTRAR}    accessibility_id=login_button
${ERRO}      accessibility_id=login_error

*** Test Cases ***
Login Com Senha Incorreta
    Realizar Login    qa@teste.com    senhaErrada

    Wait Until Element Is Visible    ${ERRO}    10s
    Element Text Should Be    ${ERRO}    Email ou senha inválidos

*** Keywords ***
Realizar Login
    [Arguments]    ${email}    ${senha}

    Input Text    ${EMAIL}    ${email}
    Input Text    ${SENHA}    ${senha}
    Click Element    ${ENTRAR}


*** Settings ***
Library    AppiumLibrary

*** Variables ***
${EMAIL_INPUT}       accessibility_id=email_input
${PASSWORD_INPUT}    accessibility_id=password_input
${LOGIN_BUTTON}      accessibility_id=login_button
${ERROR_MESSAGE}     accessibility_id=login_error

*** Test Cases ***
Validar Login Invalido
    Input Text    ${EMAIL_INPUT}    qa@teste.com
    Input Text    ${PASSWORD_INPUT}    senhaErrada

    Click Element    ${LOGIN_BUTTON}

    Wait Until Element Is Visible    ${ERROR_MESSAGE}    10s
    Element Text Should Be    ${ERROR_MESSAGE}    Email ou senha inválidos


*** Settings ***
Library    AppiumLibrary

*** Variables ***
${EMAIL_INPUT}       accessibility_id=email_input
${PASSWORD_INPUT}    accessibility_id=password_input
${LOGIN_BUTTON}      accessibility_id=login_button
${ERROR_MESSAGE}     accessibility_id=login_error

*** Test Cases ***
Validar Login Invalido
    Realizar Login    qa@teste.com    senhaErrada

    Wait Until Element Is Visible    ${ERROR_MESSAGE}    10s
    Element Text Should Be    ${ERROR_MESSAGE}    Email ou senha inválidos

*** Keywords ***
Realizar Login
    [Arguments]    ${email}    ${senha}

    Input Text    ${EMAIL_INPUT}    ${email}
    Input Text    ${PASSWORD_INPUT}    ${senha}
    Click Element    ${LOGIN_BUTTON}



*** Settings ***
Library    AppiumLibrary

*** Variables ***
${EMAIL_INPUT}       accessibility_id=email_input
${PASSWORD_INPUT}    accessibility_id=password_input
${LOGIN_BUTTON}      accessibility_id=login_button
${ERROR_MESSAGE}     accessibility_id=login_error

*** Test Cases ***
Validar Outro Login Invalido
    Realizar Login    usuario@teste.com    123456

    Wait Until Element Is Visible    ${ERROR_MESSAGE}    10s

    Element Text Should Be    ${ERROR_MESSAGE}    Email ou senha inválidos

*** Keywords ***
Realizar Login
    [Arguments]    ${email}    ${senha}

    Input Text    ${EMAIL_INPUT}    ${email}
    Input Text    ${PASSWORD_INPUT}    ${senha}
    Click Element    ${LOGIN_BUTTON}


*** Settings ***
Library    BuiltIn

*** Test Cases ***
Validar Desconto
    ${resultado}=    Calcular Desconto    ${150}
    Should Be Equal As Numbers    ${resultado}    15

Validar Sem Desconto
    ${resultado}=    Calcular Desconto    ${50}
    Should Be Equal As Numbers    ${resultado}    0

*** Keywords ***
Calcular Desconto
    [Arguments]    ${subtotal}

    IF    ${subtotal}    >=    100
        ${desconto}=    Evaluate    $subtotal * 0.10
        RETURN    ${desconto}
    END

    RETURN    ${0}


*** Settings ***
Library    BuiltIn

*** Test Cases ***
Validar Frete Gratis
    ${frete}=    Calcular Frete    ${150}
    Should Be Equal As Numbers    ${frete}    0

Validar Frete Pago
    ${frete}=    Calcular Frete    ${100}
    Should Be Equal As Numbers    ${frete}    20

*** Keywords ***
Calcular Frete
    [Arguments]    ${subtotal}

    IF    $subtotal >= 150
        RETURN    ${0}
    ELSE
        RETURN    ${20}
    END


*** Settings ***
Library    BuiltIn

*** Test Cases ***
Validar Pedido Baixo
    ${resultado}=    Classificar Pedido    ${50}
    Should Be Equal    ${resultado}    Baixo

Validar Pedido Medio
    ${resultado}=    Classificar Pedido    ${150}
    Should Be Equal    ${resultado}    Medio

Validar Pedido Alto
    ${resultado}=    Classificar Pedido    ${200}
    Should Be Equal    ${resultado}    Alto

*** Keywords ***
Classificar Pedido
    [Arguments]    ${subtotal}

    IF    $subtotal < 100
        RETURN    Baixo
    ELSE IF    $subtotal < 200
        RETURN    Medio
    ELSE
        RETURN    Alto
    END


*** Settings ***
Library    BuiltIn

*** Test Cases ***
Validar Soma De Produtos Elegiveis
    @{precos}=    Create List    ${50}    ${120}    ${200}

    ${resultado}=    Somar Produtos Elegiveis    @{precos}

    Should Be Equal As Numbers    ${resultado}    320

*** Keywords ***
Somar Produtos Elegiveis
    [Arguments]    @{precos}

    ${total}=    Set Variable    ${0}

    FOR    ${preco}    IN    @{precos}
        IF    $preco >= 100
            ${total}=    Evaluate    $total + $preco
        END
    END

    RETURN    ${total}


*** Settings ***
Library    BuiltIn

*** Test Cases ***
Validar Compra Sem Desconto
    ${resultado}=    Calcular Total Com Desconto    ${50}
    Should Be Equal As Numbers    ${resultado}    50

Validar Desconto No Limite
    ${resultado}=    Calcular Total Com Desconto    ${100}
    Should Be Equal As Numbers    ${resultado}    90

Validar Compra Com Desconto
    ${resultado}=    Calcular Total Com Desconto    ${200}
    Should Be Equal As Numbers    ${resultado}    180

*** Keywords ***
Calcular Total Com Desconto
    [Arguments]    ${subtotal}

    IF    $subtotal >= 100
        ${total}=    Evaluate    $subtotal * 0.90
        RETURN    ${total}
    END

    RETURN    ${subtotal}



*** Settings ***
Library    AppiumLibrary

*** Variables ***
${SUBTOTAL_INPUT}     accessibility_id=subtotal_input
${CALCULAR_BUTTON}    accessibility_id=calculate_button
${TOTAL_LABEL}        accessibility_id=total_label

*** Test Cases ***
Validar Total Da Compra
    ${esperado}=    Calcular Total Com Desconto    ${200}

    Input Text    ${SUBTOTAL_INPUT}    200
    Click Element    ${CALCULAR_BUTTON}

    Wait Until Keyword Succeeds
    ...    10s
    ...    500ms
    ...    Validar Total Exibido
    ...    ${esperado}

*** Keywords ***
Calcular Total Com Desconto
    [Arguments]    ${subtotal}

    IF    $subtotal >= 100
        ${total}=    Evaluate    $subtotal * 0.90
        RETURN    ${total}
    END

    RETURN    ${subtotal}

Validar Total Exibido
    [Arguments]    ${esperado}

    ${resultado}=    Get Text    ${TOTAL_LABEL}
    Should Be Equal As Numbers    ${resultado}    ${esperado}

