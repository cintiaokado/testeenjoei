import { defineConfig } from 'cypress';

export default defineConfig({
  e2e: {
    baseUrl: 'https://www.saucedemo.com',
    testIsolation: true,
    defaultCommandTimeout: 10000
  },

  env: {
    SAUCE_PASSWORD: 'secret_sauce'
  }
});