
import { selectors } from '../selectors';

export function login(
  username: string,
  password: string
): void {
  cy.visit('/');

  cy.get(selectors.login.username).type(username);
  cy.get(selectors.login.password).type(password);
  cy.get(selectors.login.submit).click();
}
