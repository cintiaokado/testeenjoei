
import {
  selectors,
  productSelectors
} from '../selectors';

export function adicionarProduto(
  productId: string
): void {
  cy.get(productSelectors.addButton(productId))
    .should('be.visible')
    .and('be.enabled')
    .click();
}

export function removerProduto(
  productId: string
): void {
  cy.get(productSelectors.removeButton(productId))
    .should('be.visible')
    .click();
}

export function abrirCarrinho(): void {
  cy.get(selectors.cart.link).click();
}
