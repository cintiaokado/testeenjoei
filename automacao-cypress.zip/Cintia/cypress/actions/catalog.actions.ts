import { selectors } from '../selectors';

/** Seleciona a ordenação nativa do catálogo SauceDemo. */
export type OrdenacaoCatalogo = 'az' | 'za' | 'lohi' | 'hilo';

export function ordenarProdutos(ordenacao: OrdenacaoCatalogo): void {
  cy.get(selectors.catalog.sort)
    .should('be.visible')
    .select(ordenacao);
}

/** Abre a página de detalhes pelo nome visível do produto. */
export function abrirDetalhesProduto(nome: string): void {
  cy.get(selectors.catalog.item)
    .contains(selectors.catalog.itemName, nome)
    .should('be.visible')
    .click();
}

/** Obtém os nomes renderizados, preservando a ordem exibida. */
export function obterNomesProdutos(): Cypress.Chainable<string[]> {
  return cy.get(selectors.catalog.itemName).then(($items) =>
    Array.from($items, (item) => item.textContent?.trim() ?? '')
  );
}

/** Obtém os preços em centavos, evitando erros com ponto flutuante. */
export function obterPrecosEmCentavos(): Cypress.Chainable<number[]> {
  return cy.get(selectors.catalog.itemPrice).then(($items) =>
    Array.from($items, (item) => {
      const texto = item.textContent?.trim() ?? '';
      const normalizado = texto.replace(/[^\d.,]/g, '').replace(',', '.');
      const valor = Number(normalizado);
      if (!normalizado || !Number.isFinite(valor)) {
        throw new Error(`Preço inválido no catálogo: ${texto}`);
      }
      return Math.round(valor * 100);
    })
  );
}

/** Abre catálogo por navegação explícita; exige sessão autenticada. */
export function abrirCatalogo(): void {
  cy.visit('/inventory.html');
  cy.get(selectors.catalog.list).should('be.visible');
}
