
import { selectors } from '../selectors';

export type Comprador = {
  firstName: string;
  lastName: string;
  postalCode: string;
};

export function preencherComprador(
  comprador: Comprador
): void {
  cy.get(selectors.checkout.firstName)
    .type(comprador.firstName);

  cy.get(selectors.checkout.lastName)
    .type(comprador.lastName);

  cy.get(selectors.checkout.postalCode)
    .type(comprador.postalCode);
}

export function continuarCheckout(): void {
  cy.get(selectors.checkout.continue).click();
}

export function finalizarCompra(): void {
  cy.get(selectors.checkout.finish).click();
}
