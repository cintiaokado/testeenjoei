
declare namespace Cypress {
  interface Chainable {
    loginAsStandardUser(): Chainable<void>;
  }
}
