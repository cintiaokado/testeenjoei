
import { selectors } from '../../../selectors';
import { login } from '../../../actions/auth.actions';

import users from '../../../fixtures/users.json';

describe('SauceDemo - Autenticação', () => {

  it('TC01 - Login com usuário válido', () => {
    login(users.standard.username, users.standard.password);

    cy.url().should('include', '/inventory.html');

    cy.get(selectors.catalog.list)
      .should('be.visible');

    cy.get(selectors.catalog.item)
      .should('have.length.greaterThan', 0);
  });

  it('TC02 - Usuário bloqueado não deve autenticar', () => {
    login(users.locked.username, users.locked.password);

    cy.get(selectors.login.error)
      .should('be.visible')
      .and('contain.text', 'Sorry, this user has been locked out');

    cy.url().should('not.include', '/inventory.html');
  });

  it('TC03 - Não permitir acesso sem autenticação', () => {
    cy.visit('/inventory.html', {
      failOnStatusCode: false
    });

    cy.get(selectors.login.username)
      .should('be.visible');

    cy.url().should('not.include', '/inventory.html');
  });

  it('TC15 - Login com senha incorreta', () => {
    login(users.invalid.username, users.invalid.password);

    cy.get(selectors.login.error)
      .should('be.visible')
      .and('contain.text', 'Username and password do not match');

    cy.url().should('not.include', '/inventory.html');
  });

  it('TC16 - Logout deve encerrar sessão', () => {
    login(users.standard.username, users.standard.password);

    cy.get(selectors.menu.open).click();

    cy.get(selectors.menu.logout)
      .should('be.visible')
      .click();

    cy.get(selectors.login.username)
      .should('be.visible');

    cy.url().should('not.include', '/inventory.html');

    cy.visit('/inventory.html', {
      failOnStatusCode: false
    });

    cy.get(selectors.login.username)
      .should('be.visible');
  });

});
