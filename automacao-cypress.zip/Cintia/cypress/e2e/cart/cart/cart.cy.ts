
import { selectors } from '../../../selectors';
import {
  adicionarProduto,
  abrirCarrinho
} from '../../../actions/cart.actions';

import products from './../../../fixtures/products.json';

describe('Carrinho de compras', () => {
  beforeEach(() => {
    cy.loginAsStandardUser();
  });

  it('TC04 - adiciona um produto ao carrinho', () => {
    adicionarProduto(products.backpack.id);

    cy.get(selectors.cart.badge)
      .should('have.text', '1');

    abrirCarrinho();

    cy.get(selectors.cart.item)
      .should('have.length', 1)
      .within(() => {
        cy.get(selectors.catalog.itemName)
          .should('have.text', products.backpack.name);

        cy.get(selectors.catalog.itemPrice)
          .should('have.text', '$29.99');
      });
  });
});
