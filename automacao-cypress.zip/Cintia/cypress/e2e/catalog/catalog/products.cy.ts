import { selectors } from '../../../selectors';
import products from '../../../fixtures/products.json';

describe('Catálogo — informações dos produtos', () => {
  beforeEach(() => {
    cy.loginAsStandardUser();
  });

  it('TC19 - mantém nome e preço consistentes entre catálogo e detalhe', () => {
    const produto = products.backpack;

    // O item é escolhido pelo nome, sem depender de sua posição no catálogo.
    cy.get(selectors.catalog.item)
      .contains(selectors.catalog.itemName, produto.name)
      .closest(selectors.catalog.item)
      .within(() => {
        cy.get(selectors.catalog.itemPrice)
          .should('have.text', `$${produto.price.toFixed(2)}`);
        cy.get(selectors.catalog.itemName).click();
      });

    cy.url().should('include', '/inventory-item.html');
    cy.get('[data-test="inventory-item-name"]')
      .should('have.text', produto.name);
    cy.get('[data-test="inventory-item-price"]')
      .should('have.text', `$${produto.price.toFixed(2)}`);
  });

  it('exibe produtos com nome e preço preenchidos', () => {
    cy.get(selectors.catalog.item).should('have.length.greaterThan', 0);
    cy.get(selectors.catalog.item).each(($item) => {
      cy.wrap($item).find(selectors.catalog.itemName)
        .invoke('text').should('not.be.empty');
      cy.wrap($item).find(selectors.catalog.itemPrice)
        .invoke('text').should('match', /^\$\d+\.\d{2}$/);
    });
  });
});
