import { selectors } from '../../../selectors';

type Ordem = 'asc' | 'desc';

function obterPrecos(): Cypress.Chainable<number[]> {
  return cy.get(selectors.catalog.itemPrice).then(($prices) =>
    [...$prices].map((element) => {
      const value = Number(element.textContent?.replace(/[^0-9.]/g, '') ?? '');
      expect(Number.isFinite(value), 'preço numérico válido').to.eq(true);
      return value;
    })
  );
}

function obterNomes(): Cypress.Chainable<string[]> {
  return cy.get(selectors.catalog.itemName).then(($names) =>
    [...$names].map((element) => element.textContent?.trim() ?? '')
  );
}

function validarOrdenacaoDePreco(ordem: Ordem): void {
  obterPrecos().then((precos) => {
    expect(precos.length, 'produtos visíveis').to.be.greaterThan(0);
    const esperado = [...precos].sort((a, b) =>
      ordem === 'asc' ? a - b : b - a
    );
    expect(precos).to.deep.equal(esperado);
  });
}

function validarOrdenacaoDeNome(ordem: Ordem): void {
  obterNomes().then((nomes) => {
    expect(nomes.length, 'produtos visíveis').to.be.greaterThan(0);
    const esperado = [...nomes].sort((a, b) =>
      ordem === 'asc' ? a.localeCompare(b, 'en') : b.localeCompare(a, 'en')
    );
    expect(nomes).to.deep.equal(esperado);
  });
}

describe('Catálogo — ordenação', () => {
  beforeEach(() => cy.loginAsStandardUser());

  it('TC17 - ordena por preço crescente', () => {
    cy.get(selectors.catalog.sort).select('lohi');
    cy.get(selectors.catalog.sort).should('have.value', 'lohi');
    validarOrdenacaoDePreco('asc');
  });

  it('TC18 - ordena por preço decrescente', () => {
    cy.get(selectors.catalog.sort).select('hilo');
    cy.get(selectors.catalog.sort).should('have.value', 'hilo');
    validarOrdenacaoDePreco('desc');
  });

  it('TC21 - ordena produtos de A a Z', () => {
    cy.get(selectors.catalog.sort).select('az');
    cy.get(selectors.catalog.sort).should('have.value', 'az');
    validarOrdenacaoDeNome('asc');
  });

  it('TC21 - ordena produtos de Z a A', () => {
    cy.get(selectors.catalog.sort).select('za');
    cy.get(selectors.catalog.sort).should('have.value', 'za');
    validarOrdenacaoDeNome('desc');
  });
});
