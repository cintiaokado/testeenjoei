
import { selectors } from '../../../selectors';
import { adicionarProduto, abrirCarrinho }
  from '../../../actions/cart.actions';
import { preencherComprador, continuarCheckout }
  from '../../../actions/checkout.actions';

import products from '../../../fixtures/products.json';
import checkout from '../../../fixtures/checkout.json';

describe('Checkout', () => {
  beforeEach(() => {
    cy.loginAsStandardUser();
  });

  it('TC08 - valida subtotal e total da compra', () => {
    adicionarProduto(products.backpack.id);
    abrirCarrinho();

    cy.get(selectors.cart.checkout).click();

    preencherComprador(checkout.compradorValido);
    continuarCheckout();

    cy.get(selectors.checkout.subtotal)
      .should('contain.text', '29.99');

    cy.get(selectors.checkout.tax)
      .invoke('text')
      .then((textoImposto) => {
        const imposto = Number(
          textoImposto.replace('Tax: $', '')
        );

        expect(imposto).to.be.at.least(0);

        cy.get(selectors.checkout.total)
          .should('have.text', `Total: $${(
            products.backpack.price + imposto
          ).toFixed(2)}`);
      });
  });
});
