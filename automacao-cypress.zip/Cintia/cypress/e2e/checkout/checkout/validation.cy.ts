import { selectors, productSelectors } from '../../../selectors';
import products from '../../../fixtures/products.json';
import checkout from '../../../fixtures/checkout.json';

type Campo = 'firstName' | 'lastName' | 'postalCode';

type Cenario = {
  id: string;
  descricao: string;
  vazio: Campo;
  mensagem: string;
};

const cenarios: Cenario[] = [
  {
    id: 'TC12',
    descricao: 'primeiro nome obrigatório',
    vazio: 'firstName',
    mensagem: 'Error: First Name is required'
  },
  {
    id: 'TC13',
    descricao: 'sobrenome obrigatório',
    vazio: 'lastName',
    mensagem: 'Error: Last Name is required'
  },
  {
    id: 'TC14',
    descricao: 'código postal obrigatório',
    vazio: 'postalCode',
    mensagem: 'Error: Postal Code is required'
  }
];

function abrirFormularioDeCheckout(): void {
  cy.get(productSelectors.addButton(products.backpack.id))
    .should('be.visible')
    .click();
  cy.get(selectors.cart.badge).should('have.text', '1');
  cy.get(selectors.cart.link).click();
  cy.get(selectors.cart.checkout).should('be.enabled').click();
  cy.url().should('include', '/checkout-step-one.html');
}

function preencherCampoSeNaoVazio(seletor: string, valor: string): void {
  if (valor !== '') cy.get(seletor).type(valor);
}

describe('Checkout — campos obrigatórios', () => {
  beforeEach(() => {
    cy.loginAsStandardUser();
    abrirFormularioDeCheckout();
  });

  cenarios.forEach(({ id, descricao, vazio, mensagem }) => {
    it(`${id} - valida ${descricao}`, () => {
      const comprador = checkout.compradorValido;
      const dados = {
        firstName: vazio === 'firstName' ? '' : comprador.firstName,
        lastName: vazio === 'lastName' ? '' : comprador.lastName,
        postalCode: vazio === 'postalCode' ? '' : comprador.postalCode
      };

      preencherCampoSeNaoVazio(selectors.checkout.firstName, dados.firstName);
      preencherCampoSeNaoVazio(selectors.checkout.lastName, dados.lastName);
      preencherCampoSeNaoVazio(selectors.checkout.postalCode, dados.postalCode);

      cy.get(selectors.checkout.continue).click();
      cy.get(selectors.checkout.error)
        .should('be.visible')
        .and('have.text', mensagem);
      cy.url().should('include', '/checkout-step-one.html');
    });
  });
});
