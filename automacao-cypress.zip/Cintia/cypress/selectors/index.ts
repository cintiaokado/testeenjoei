
export const selectors = {  
  menu: {
    open: '#react-burger-menu-btn',
    logout: '#logout_sidebar_link'
 },
  
  login: {
    username: '[data-test="username"]',
    password: '[data-test="password"]',
    submit: '[data-test="login-button"]',
    error: '[data-test="error"]'
  },

  catalog: {
    list: '[data-test="inventory-list"]',
    item: '[data-test="inventory-item"]',
    itemName: '[data-test="inventory-item-name"]',
    itemPrice: '[data-test="inventory-item-price"]',
    sort: '[data-test="product-sort-container"]'
  },

  cart: {
    link: '[data-test="shopping-cart-link"]',
    badge: '[data-test="shopping-cart-badge"]',
    item: '[data-test="inventory-item"]',
    checkout: '[data-test="checkout"]'
  },

  checkout: {
    firstName: '[data-test="firstName"]',
    lastName: '[data-test="lastName"]',
    postalCode: '[data-test="postalCode"]',
    continue: '[data-test="continue"]',
    finish: '[data-test="finish"]',
    error: '[data-test="error"]',
    subtotal: '[data-test="subtotal-label"]',
    tax: '[data-test="tax-label"]',
    total: '[data-test="total-label"]',
    confirmation: '[data-test="complete-header"]'
  }
} as const;

export const productSelectors = {
  addButton: (productId: string) =>
    `[data-test="add-to-cart-${productId}"]`,

  removeButton: (productId: string) =>
    `[data-test="remove-${productId}"]`
};
