
import { login } from '../actions/auth.actions';

Cypress.Commands.add('loginAsStandardUser', () => {
  const password = Cypress.env('SAUCE_PASSWORD');

  if (typeof password !== 'string' || !password) {
    throw new Error('SAUCE_PASSWORD não configurada');
  }

  login('standard_user', password);

  cy.url().should('include', '/inventory.html');
});
