# SauceDemo — Automacao web mobile com Robot + Appium

Projeto didatico para Android + Chrome usando **AppiumLibrary**, com testes agrupados por dominio, keywords reutilizaveis, localizadores centralizados e massas separadas.

## Estrutura

- `tests/`: 24 cenarios (21 candidatos a automacao e 3 pendentes, marcados `robot:skip`).
- `resources/keywords/`: operacoes e validacoes por camada funcional.
- `resources/locators/`: seletores web CSS/ID (a validar no DOM mobile).
- `variables/config.py`: endereco Appium, browser e usuarios publicos demo, configuraveis por variaveis de ambiente.
- `variables/testdata.robot`: dados funcionais e oraculos.
- `results/`: logs, XML e HTML gerados pelo Robot.

## Requisitos

1. Python 3.10+ e VS Code com extensao Robot Framework Language Server.
2. Appium Server 2/3 instalado e rodando na porta 4723; driver `uiautomator2`.
3. Android SDK, dispositivo/emulador acessivel por `adb devices` e Google Chrome instalado.
4. Versao do Chrome e Chromedriver/gerenciamento automatico compatíveis.

## Instalacao

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
appium driver install uiautomator2
appium
```

Em **outro terminal**:

```powershell
robot --dryrun -d results tests
robot -d results --include smoke tests
robot -d results tests
```

Para executar um arquivo apenas:

```powershell
robot -d results tests/01_auth.robot
```

## Avisos essenciais

- Esta suite **nao foi executada em dispositivo mobile**. Executar `--dryrun` valida estrutura/keywords, nao os seletores, regras ou Appium.
- Localizadores sao referencias publicas, sem inspeção DevTools ao vivo; validar cada um e corrigir antes do uso.
- Valor de 8% de imposto no TC07 e os oraculos monetarios sao referencias de demonstracao, **nao contrato verificado**.
- Os tres cenarios TC22–24 estao marcados `robot:skip` por falta de oraculos/requisitos; nao contam como testes automatizados implementados.
- `Go To Url` opera o navegador Chrome Android; SauceDemo e web mobile, **nao app nativo**.
- O projeto usa credenciais **publicas de demonstracao**. Em aplicacoes reais, fornecer secrets por ambiente/secret manager.
- A suite nao depende de execucao de testes anteriores; cada teste abre um novo navegador e fecha no teardown.
- Avaliar `Go To Url` e deteccao de paginas internas no dispositivo real: comportamento do SauceDemo pode variar.
- Oraculos e seletores devem ser validados no Chrome Android antes de considerar a suite pronta para CI.

## Matriz de cenarios

| Testes | Escopo |
| --- | --- |
| TC01–03, TC15–16 | Autenticacao e sessao |
| TC17–19, TC21 | Catalogo e ordenacao |
| TC04–05, TC10–11 | Carrinho |
| TC06–09, TC20 | Checkout e resumo |
| TC12–14 | Validacoes do checkout |
| TC22–24 | Pendencias exploratorias, nao automatizadas |

## Proximo passo

Confirmar IDs no Chrome mobile com DevTools remoto (`chrome://inspect`), executar smoke, diagnosticar falhas reais e so entao criar baseline de CI.
