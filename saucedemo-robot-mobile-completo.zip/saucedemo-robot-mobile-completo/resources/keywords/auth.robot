*** Settings ***
Library    AppiumLibrary
Resource    ../locators/saucedemo.robot
Variables    ../../variables/config.py

*** Keywords ***
Efetuar Login
    [Arguments]    ${usuario}    ${senha}
    Wait Until Element Is Visible    ${LOGIN_USERNAME}    15s
    Input Text    ${LOGIN_USERNAME}    ${usuario}
    Input Text    ${LOGIN_PASSWORD}    ${senha}
    Click Element    ${LOGIN_BUTTON}

Fazer Login Como Usuario Padrao
    Efetuar Login    ${SAUCE_USERNAME}    ${SAUCE_PASSWORD}
    Wait Until Element Is Visible    ${PRODUCTS_LIST}    15s

Validar Falha De Login
    [Arguments]    ${mensagem}
    Wait Until Element Is Visible    ${LOGIN_ERROR}    10s
    ${texto}=    Get Text    ${LOGIN_ERROR}
    Should Contain    ${texto}    ${mensagem}
    Page Should Not Contain Element    ${PRODUCTS_LIST}

Fazer Logout
    Click Element    ${MENU_OPEN}
    Wait Until Element Is Visible    ${MENU_LOGOUT}    10s
    Click Element    ${MENU_LOGOUT}
    Wait Until Element Is Visible    ${LOGIN_USERNAME}    10s
