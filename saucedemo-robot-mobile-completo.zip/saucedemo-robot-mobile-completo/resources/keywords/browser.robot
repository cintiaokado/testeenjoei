*** Settings ***
Library    AppiumLibrary
Variables    ../../variables/config.py
Resource    ../locators/saucedemo.robot

*** Keywords ***
Abrir SauceDemo No Chrome Mobile
    Open Application    ${APPIUM_URL}    platformName=Android    automationName=UiAutomator2    deviceName=${DEVICE_NAME}    browserName=Chrome
    Go To Url    ${BASE_URL}
    Wait Until Element Is Visible    ${LOGIN_USERNAME}    15s

Encerrar Navegador Mobile
    Run Keyword If Test Failed    Capturar Evidencia Da Falha
    Run Keyword And Ignore Error    Close Application

Capturar Evidencia Da Falha
    Run Keyword And Ignore Error    Capture Page Screenshot

Ir Para Pagina Interna
    [Arguments]    ${caminho}
    Go To Url    ${BASE_URL}${caminho}

Validar Pagina Atual
    [Arguments]    ${trecho_url}
    ${url}=    Get Window Url
    Should Contain    ${url}    ${trecho_url}
