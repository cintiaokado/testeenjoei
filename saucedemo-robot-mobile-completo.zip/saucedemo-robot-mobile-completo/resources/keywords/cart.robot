*** Settings ***
Library    AppiumLibrary
Resource    ../locators/saucedemo.robot

*** Keywords ***
Adicionar Produto Ao Carrinho
    [Arguments]    ${slug}
    ${botao}=    Set Variable    css:[data-test="add-to-cart-${slug}"]
    Wait Until Element Is Visible    ${botao}    10s
    Click Element    ${botao}
    Wait Until Element Is Visible    css:[data-test="remove-${slug}"]    10s

Remover Produto Do Carrinho
    [Arguments]    ${slug}
    ${botao}=    Set Variable    css:[data-test="remove-${slug}"]
    Wait Until Element Is Visible    ${botao}    10s
    Click Element    ${botao}

Validar Contador Do Carrinho
    [Arguments]    ${quantidade}
    Wait Until Keyword Succeeds    10s    500ms    Element Text Should Be    ${CART_BADGE}    ${quantidade}

Validar Carrinho Vazio
    Wait Until Keyword Succeeds    10s    500ms    Page Should Not Contain Element    ${CART_BADGE}
    Page Should Not Contain Element    ${CART_ITEM}

Abrir Carrinho
    Click Element    ${CART_LINK}
    Wait Until Element Is Visible    ${CHECKOUT_BUTTON}    10s

Validar Produto No Carrinho
    [Arguments]    ${nome}    ${preco}
    ${nomes}=    Get Text    ${CART_ITEM_NAME}
    Should Be Equal    ${nomes}    ${nome}
    ${valor}=    Get Text    ${CART_ITEM_PRICE}
    Should Be Equal    ${valor}    $${preco}

Validar Quantidade De Itens No Carrinho
    [Arguments]    ${esperado}
    ${itens}=    Get Webelements    ${CART_ITEM}
    ${quantidade}=    Get Length    ${itens}
    Should Be Equal As Integers    ${quantidade}    ${esperado}

Voltar Para Catalogo
    Click Element    ${CART_CONTINUE}
    Wait Until Element Is Visible    ${PRODUCTS_LIST}    10s
