*** Settings ***
Library    AppiumLibrary
Library    Collections
Resource    ../locators/saucedemo.robot

*** Keywords ***
Validar Catalogo Disponivel
    Wait Until Element Is Visible    ${PRODUCTS_LIST}    15s
    ${nomes}=    Get Webelements    ${PRODUCT_NAME}
    ${quantidade}=    Get Length    ${nomes}
    Should Be True    ${quantidade} > 0

Abrir Detalhes Da Mochila
    Wait Until Element Is Visible    ${PRODUCTS_LIST}    15s
    Click Element    css:[data-test="item-4-title-link"]
    Wait Until Element Is Visible    ${PRODUCT_NAME}    10s

Ordenar Produtos
    [Arguments]    ${valor}
    Wait Until Element Is Visible    ${PRODUCT_SORT}    10s
    Click Element    ${PRODUCT_SORT}
    Click Element    css:[data-test="product-sort-container"] option[value="${valor}"]

Obter Precos Exibidos
    @{precos}=    Create List
    ${elementos}=    Get Webelements    ${PRODUCT_PRICE}
    FOR    ${elemento}    IN    @{elementos}
        ${texto}=    Call Method    ${elemento}    get_attribute    textContent
        ${numero}=    Evaluate    float($texto.replace('$', '').strip())
        Append To List    ${precos}    ${numero}
    END
    RETURN    ${precos}

Validar Precos Ordenados
    [Arguments]    ${direcao}=asc
    ${precos}=    Obter Precos Exibidos
    ${esperados}=    Evaluate    sorted($precos, reverse=($direcao == 'desc'))
    Lists Should Be Equal    ${precos}    ${esperados}
