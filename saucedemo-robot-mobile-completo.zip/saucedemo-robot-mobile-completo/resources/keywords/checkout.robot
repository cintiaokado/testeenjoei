*** Settings ***
Library    AppiumLibrary
Library    Collections
Resource    ../locators/saucedemo.robot
Resource    ../../variables/testdata.robot

*** Keywords ***
Iniciar Checkout
    Wait Until Element Is Visible    ${CHECKOUT_BUTTON}    10s
    Click Element    ${CHECKOUT_BUTTON}
    Wait Until Element Is Visible    ${FIRST_NAME_INPUT}    10s

Preencher Dados Do Comprador
    [Arguments]    ${nome}    ${sobrenome}    ${cep}
    IF    $nome != ''
        Input Text    ${FIRST_NAME_INPUT}    ${nome}
    END
    IF    $sobrenome != ''
        Input Text    ${LAST_NAME_INPUT}    ${sobrenome}
    END
    IF    $cep != ''
        Input Text    ${ZIP_INPUT}    ${cep}
    END

Continuar Checkout
    Click Element    ${CONTINUE_BUTTON}

Validar Erro No Checkout
    [Arguments]    ${mensagem}
    Wait Until Element Is Visible    ${CHECKOUT_ERROR}    10s
    ${texto}=    Get Text    ${CHECKOUT_ERROR}
    Should Contain    ${texto}    ${mensagem}

Preencher Dados E Abrir Resumo
    [Arguments]    ${nome}    ${sobrenome}    ${cep}
    Iniciar Checkout
    Preencher Dados Do Comprador    ${nome}    ${sobrenome}    ${cep}
    Continuar Checkout
    Wait Until Element Is Visible    ${SUBTOTAL_LABEL}    10s

Extrair Valor Monetario
    [Arguments]    ${texto}
    ${valor}=    Evaluate    float($texto.split('$')[-1].strip())
    RETURN    ${valor}

Validar Valores Do Resumo
    [Arguments]    ${subtotal_esperado}    ${imposto_esperado}    ${total_esperado}
    Wait Until Element Is Visible    ${SUBTOTAL_LABEL}    10s
    ${subtotal_texto}=    Get Text    ${SUBTOTAL_LABEL}
    ${imposto_texto}=    Get Text    ${TAX_LABEL}
    ${total_texto}=    Get Text    ${TOTAL_LABEL}
    ${subtotal}=    Extrair Valor Monetario    ${subtotal_texto}
    ${imposto}=    Extrair Valor Monetario    ${imposto_texto}
    ${total}=    Extrair Valor Monetario    ${total_texto}
    Should Be Equal As Numbers    ${subtotal}    ${subtotal_esperado}    precision=2
    Should Be Equal As Numbers    ${imposto}    ${imposto_esperado}    precision=2
    Should Be Equal As Numbers    ${total}    ${total_esperado}    precision=2
    ${soma}=    Evaluate    round($subtotal + $imposto, 2)
    Should Be Equal As Numbers    ${total}    ${soma}    precision=2

Validar Resumo Da Mochila
    ${nome}=    Get Text    ${CART_ITEM_NAME}
    Should Be Equal    ${nome}    ${BACKPACK_NAME}
    ${preco}=    Get Text    ${CART_ITEM_PRICE}
    Should Be Equal    ${preco}    $29.99

Finalizar E Validar Confirmacao
    Wait Until Element Is Visible    ${FINISH_BUTTON}    10s
    Click Element    ${FINISH_BUTTON}
    Wait Until Keyword Succeeds    10s    500ms    Element Text Should Be    ${SUCCESS_HEADER}    ${SUCCESS_MESSAGE}

Cancelar Checkout
    Click Element    ${CHECKOUT_CANCEL}
