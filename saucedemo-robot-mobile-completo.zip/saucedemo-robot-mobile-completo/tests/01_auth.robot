*** Settings ***
Resource    ../resources/keywords/browser.robot
Resource    ../resources/keywords/auth.robot
Resource    ../resources/keywords/catalog.robot
Resource    ../resources/keywords/cart.robot
Resource    ../resources/keywords/checkout.robot
Resource    ../variables/testdata.robot
Variables    ../variables/config.py
Test Setup    Abrir SauceDemo No Chrome Mobile
Test Teardown    Encerrar Navegador Mobile

*** Test Cases ***
TC01 Login Valido
    [Tags]    smoke    p0    auth
    Fazer Login Como Usuario Padrao
    Validar Catalogo Disponivel

TC02 Usuario Bloqueado
    [Tags]    smoke    p0    auth    negative
    Efetuar Login    ${LOCKED_USERNAME}    ${SAUCE_PASSWORD}
    Validar Falha De Login    ${ERROR_LOCKED}

TC03 Acesso Sem Autenticacao
    [Tags]    p0    auth    negative    verify-mobile
    Ir Para Pagina Interna    inventory.html
    Wait Until Element Is Visible    ${LOGIN_USERNAME}    10s
    Page Should Not Contain Element    ${PRODUCTS_LIST}

TC15 Credenciais Invalidas
    [Tags]    p1    auth    negative
    Efetuar Login    ${INVALID_USERNAME}    ${INVALID_PASSWORD}
    Validar Falha De Login    ${ERROR_INVALID}

TC16 Logout E Restricao De Acesso
    [Tags]    p1    auth    verify-mobile
    Fazer Login Como Usuario Padrao
    Fazer Logout
    Ir Para Pagina Interna    inventory.html
    Wait Until Element Is Visible    ${LOGIN_USERNAME}    10s
