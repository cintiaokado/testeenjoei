*** Settings ***
Resource    ../resources/keywords/browser.robot
Resource    ../resources/keywords/auth.robot
Resource    ../resources/keywords/catalog.robot
Resource    ../resources/keywords/cart.robot
Resource    ../resources/keywords/checkout.robot
Resource    ../variables/testdata.robot
Variables    ../variables/config.py
Test Setup    Abrir SauceDemo No Chrome Mobile
Test Teardown    Encerrar Navegador Mobile

*** Test Cases ***
TC17 Ordenar Preco Crescente
    [Tags]    p1    catalog    sorting    verify-mobile
    Fazer Login Como Usuario Padrao
    Ordenar Produtos    lohi
    Validar Precos Ordenados    asc

TC18 Ordenar Preco Decrescente
    [Tags]    p1    catalog    sorting    verify-mobile
    Fazer Login Como Usuario Padrao
    Ordenar Produtos    hilo
    Validar Precos Ordenados    desc

TC19 Abrir Detalhes Da Mochila
    [Tags]    p1    catalog    verify-mobile
    Fazer Login Como Usuario Padrao
    Abrir Detalhes Da Mochila
    Element Text Should Be    ${PRODUCT_NAME}    ${BACKPACK_NAME}

TC21 Ordenar Nome Crescente
    [Tags]    p2    catalog    sorting    verify-mobile
    Fazer Login Como Usuario Padrao
    Ordenar Produtos    az
    ${elementos}=    Get Webelements    ${PRODUCT_NAME}
    @{nomes}=    Create List
    FOR    ${elemento}    IN    @{elementos}
        ${nome}=    Call Method    ${elemento}    get_attribute    textContent
        Append To List    ${nomes}    ${nome}
    END
    ${ordenados}=    Evaluate    sorted($nomes)
    Lists Should Be Equal    ${nomes}    ${ordenados}
