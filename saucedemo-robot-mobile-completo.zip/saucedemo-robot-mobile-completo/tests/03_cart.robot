*** Settings ***
Resource    ../resources/keywords/browser.robot
Resource    ../resources/keywords/auth.robot
Resource    ../resources/keywords/catalog.robot
Resource    ../resources/keywords/cart.robot
Resource    ../resources/keywords/checkout.robot
Resource    ../variables/testdata.robot
Variables    ../variables/config.py
Test Setup    Abrir SauceDemo No Chrome Mobile
Test Teardown    Encerrar Navegador Mobile

*** Test Cases ***
TC04 Adicionar Mochila
    [Tags]    smoke    p0    cart
    Fazer Login Como Usuario Padrao
    Adicionar Produto Ao Carrinho    ${BACKPACK_SLUG}
    Validar Contador Do Carrinho    1
    Abrir Carrinho
    Validar Produto No Carrinho    ${BACKPACK_NAME}    ${BACKPACK_PRICE}

TC05 Adicionar Dois Produtos
    [Tags]    smoke    p0    cart
    Fazer Login Como Usuario Padrao
    Adicionar Produto Ao Carrinho    ${BACKPACK_SLUG}
    Adicionar Produto Ao Carrinho    ${BIKE_LIGHT_SLUG}
    Validar Contador Do Carrinho    2
    Abrir Carrinho
    Validar Quantidade De Itens No Carrinho    2

TC10 Remover Produto Do Carrinho
    [Tags]    p1    cart
    Fazer Login Como Usuario Padrao
    Adicionar Produto Ao Carrinho    ${BACKPACK_SLUG}
    Abrir Carrinho
    Remover Produto Do Carrinho    ${BACKPACK_SLUG}
    Validar Carrinho Vazio

TC11 Preservar Carrinho Entre Telas
    [Tags]    p1    cart
    Fazer Login Como Usuario Padrao
    Adicionar Produto Ao Carrinho    ${BACKPACK_SLUG}
    Abrir Carrinho
    Voltar Para Catalogo
    Validar Contador Do Carrinho    1
    Abrir Carrinho
    Validar Produto No Carrinho    ${BACKPACK_NAME}    ${BACKPACK_PRICE}
