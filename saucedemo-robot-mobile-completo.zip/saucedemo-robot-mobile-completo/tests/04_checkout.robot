*** Settings ***
Resource    ../resources/keywords/browser.robot
Resource    ../resources/keywords/auth.robot
Resource    ../resources/keywords/catalog.robot
Resource    ../resources/keywords/cart.robot
Resource    ../resources/keywords/checkout.robot
Resource    ../variables/testdata.robot
Variables    ../variables/config.py
Test Setup    Abrir SauceDemo No Chrome Mobile
Test Teardown    Encerrar Navegador Mobile

*** Test Cases ***
TC06 Compra Completa Com Um Produto
    [Tags]    smoke    p0    checkout
    Fazer Login Como Usuario Padrao
    Adicionar Produto Ao Carrinho    ${BACKPACK_SLUG}
    Abrir Carrinho
    Validar Produto No Carrinho    ${BACKPACK_NAME}    ${BACKPACK_PRICE}
    Preencher Dados E Abrir Resumo    ${BUYER_FIRST_NAME}    ${BUYER_LAST_NAME}    ${BUYER_ZIP}
    Validar Resumo Da Mochila
    Validar Valores Do Resumo    ${BACKPACK_PRICE}    ${EXPECTED_BACKPACK_TAX}    ${EXPECTED_BACKPACK_TOTAL}
    Finalizar E Validar Confirmacao

TC07 Compra Completa Com Dois Produtos
    [Tags]    p0    checkout    verify-tax-rule
    Fazer Login Como Usuario Padrao
    Adicionar Produto Ao Carrinho    ${BACKPACK_SLUG}
    Adicionar Produto Ao Carrinho    ${BIKE_LIGHT_SLUG}
    Abrir Carrinho
    Validar Quantidade De Itens No Carrinho    2
    Preencher Dados E Abrir Resumo    ${BUYER_FIRST_NAME}    ${BUYER_LAST_NAME}    ${BUYER_ZIP}
    ${subtotal}=    Evaluate    float($BACKPACK_PRICE) + float($BIKE_LIGHT_PRICE)
    ${imposto}=    Evaluate    round($subtotal * 0.08, 2)
    ${total}=    Evaluate    round($subtotal + $imposto, 2)
    Validar Valores Do Resumo    ${subtotal}    ${imposto}    ${total}
    Finalizar E Validar Confirmacao

TC08 Verificar Resumo Financeiro
    [Tags]    smoke    p0    checkout
    Fazer Login Como Usuario Padrao
    Adicionar Produto Ao Carrinho    ${BACKPACK_SLUG}
    Abrir Carrinho
    Preencher Dados E Abrir Resumo    ${BUYER_FIRST_NAME}    ${BUYER_LAST_NAME}    ${BUYER_ZIP}
    Validar Valores Do Resumo    ${BACKPACK_PRICE}    ${EXPECTED_BACKPACK_TAX}    ${EXPECTED_BACKPACK_TOTAL}

TC09 Produto Correto No Resumo
    [Tags]    smoke    p0    checkout
    Fazer Login Como Usuario Padrao
    Adicionar Produto Ao Carrinho    ${BACKPACK_SLUG}
    Abrir Carrinho
    Preencher Dados E Abrir Resumo    ${BUYER_FIRST_NAME}    ${BUYER_LAST_NAME}    ${BUYER_ZIP}
    Validar Resumo Da Mochila

TC20 Cancelar Checkout
    [Tags]    p1    checkout
    Fazer Login Como Usuario Padrao
    Adicionar Produto Ao Carrinho    ${BACKPACK_SLUG}
    Abrir Carrinho
    Iniciar Checkout
    Cancelar Checkout
    Wait Until Element Is Visible    ${CHECKOUT_BUTTON}    10s
    Validar Produto No Carrinho    ${BACKPACK_NAME}    ${BACKPACK_PRICE}
