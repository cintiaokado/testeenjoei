*** Settings ***
Resource    ../resources/keywords/browser.robot
Resource    ../resources/keywords/auth.robot
Resource    ../resources/keywords/catalog.robot
Resource    ../resources/keywords/cart.robot
Resource    ../resources/keywords/checkout.robot
Resource    ../variables/testdata.robot
Variables    ../variables/config.py
Test Setup    Abrir SauceDemo No Chrome Mobile
Test Teardown    Encerrar Navegador Mobile

*** Test Cases ***
TC12 Primeiro Nome Obrigatorio
    [Tags]    p1    checkout    negative
    Preparar Formulario De Checkout
    Preencher Dados Do Comprador    ${EMPTY}    ${BUYER_LAST_NAME}    ${BUYER_ZIP}
    Continuar Checkout
    Validar Erro No Checkout    ${ERROR_FIRST_NAME}

TC13 Sobrenome Obrigatorio
    [Tags]    p1    checkout    negative
    Preparar Formulario De Checkout
    Preencher Dados Do Comprador    ${BUYER_FIRST_NAME}    ${EMPTY}    ${BUYER_ZIP}
    Continuar Checkout
    Validar Erro No Checkout    ${ERROR_LAST_NAME}

TC14 Codigo Postal Obrigatorio
    [Tags]    p1    checkout    negative
    Preparar Formulario De Checkout
    Preencher Dados Do Comprador    ${BUYER_FIRST_NAME}    ${BUYER_LAST_NAME}    ${EMPTY}
    Continuar Checkout
    Validar Erro No Checkout    ${ERROR_ZIP}

*** Keywords ***
Preparar Formulario De Checkout
    Fazer Login Como Usuario Padrao
    Adicionar Produto Ao Carrinho    ${BACKPACK_SLUG}
    Abrir Carrinho
    Iniciar Checkout
