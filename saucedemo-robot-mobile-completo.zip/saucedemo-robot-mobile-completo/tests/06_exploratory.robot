*** Settings ***
Resource    ../resources/keywords/browser.robot
Resource    ../resources/keywords/auth.robot
Resource    ../resources/keywords/catalog.robot
Resource    ../resources/keywords/cart.robot
Resource    ../resources/keywords/checkout.robot
Resource    ../variables/testdata.robot
Variables    ../variables/config.py
Test Setup    Abrir SauceDemo No Chrome Mobile
Test Teardown    Encerrar Navegador Mobile

*** Test Cases ***
TC22 Conferir Apresentacao Visual Manualmente
    [Tags]    p2    manual    visual    robot:skip
    Log    Pendente: oraculo de screenshot aprovado e baseline mobile.

TC23 Investigar Perfil Performance Glitch
    [Tags]    p2    manual    performance    robot:skip
    Log    Pendente: criterio de tempo, dispositivo e comportamento esperado.

TC24 Validar Regra De Carrinho Vazio
    [Tags]    p2    manual    requirement-pending    robot:skip
    Log    Pendente: confirmar se checkout vazio deve ser bloqueado.
