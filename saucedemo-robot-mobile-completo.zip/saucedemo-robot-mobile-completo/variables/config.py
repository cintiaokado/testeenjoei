"""Parametros de ambiente. Credenciais sao contas publicas de demo."""
import os
BASE_URL = os.getenv("BASE_URL", "https://www.saucedemo.com/")
APPIUM_URL = os.getenv("APPIUM_URL", "http://127.0.0.1:4723")
DEVICE_NAME = os.getenv("DEVICE_NAME", "Android Emulator")
SAUCE_USERNAME = os.getenv("SAUCE_USERNAME", "standard_user")
SAUCE_PASSWORD = os.getenv("SAUCE_PASSWORD", "secret_sauce")
LOCKED_USERNAME = "locked_out_user"
INVALID_USERNAME = "invalid_user"
INVALID_PASSWORD = "senha_incorreta"
