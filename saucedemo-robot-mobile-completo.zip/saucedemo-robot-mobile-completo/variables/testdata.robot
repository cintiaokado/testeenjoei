*** Variables ***
${BACKPACK_NAME}          Sauce Labs Backpack
${BACKPACK_SLUG}          sauce-labs-backpack
${BACKPACK_PRICE}         29.99
${BIKE_LIGHT_NAME}        Sauce Labs Bike Light
${BIKE_LIGHT_SLUG}        sauce-labs-bike-light
${BIKE_LIGHT_PRICE}       9.99
${BUYER_FIRST_NAME}       Maria
${BUYER_LAST_NAME}        QA
${BUYER_ZIP}              01310000
${EXPECTED_BACKPACK_TAX}  2.40
${EXPECTED_BACKPACK_TOTAL}  32.39
${SUCCESS_MESSAGE}       Thank you for your order!
${ERROR_LOCKED}           Sorry, this user has been locked out
${ERROR_INVALID}          Username and password do not match
${ERROR_FIRST_NAME}       First Name is required
${ERROR_LAST_NAME}        Last Name is required
${ERROR_ZIP}              Postal Code is required
